import React, { Component } from 'react';
import Axios from 'axios';


class EditNewHunt extends Component {
    state = {
        clues: [],
        clue: "",
        answer: "",
        location: ""
    }

    componentDidMount() {
        const json = localStorage.getItem("clues");
        const clues = JSON.parse(json);
        console.log(clues)

        if (clues) {
            this.setState(() => ({ clues }));
        }
    }

    handleFormSubmit = () => {
        var arr = [];
        arr.push(this.state.clue)
        arr.push(this.state.answer)
        arr.push(this.state.location)
        console.log(arr)
        // localStorage.setItem(arr)
        Axios.post("/api/clues", this.state.clues)
        console.log("axios.post function hit")
    }

    handleChange = event => {
        const { name, value } = event.target;
        this.setState({
            [name]: value
        });
    }

    render() {
        return (
            <>
                <h3>Does this page work?</h3>
                <ul>
                    <li>something</li>
                    <li>something</li>
                    <li>something</li>
                    <li>something</li>
                </ul>

                <div id="clues" >
          {this.state.clues.map(clue => (
            <div className="huntDataToEdit">
                <p>{clue.clue}</p>
                {/* <input 
                    name="clue"
                    // value={this.state.clue}
                    defaultValue={clue.clue} 
                    onChange={this.handleChange} 
                    // ref={(input) => this.input = input} 
                /> */}
                <p>{clue.answer}</p>
                {/* <input
                    name="answer"
                    defaultValue={clue.answer}
                    onChange={this.handleChange}
                /> */}
                <p>{clue.location}</p>
                {/* <input 
                    name="location"
                    defaultValue={clue.location}
                    onChange={this.handleChange}
                /> */}
                <button id={clue.id}>Edit this question</button>
            </div>

          ))}
        </div>
        <button onClick={this.handleFormSubmit}>Submit</button>
            </>
        )
    }

}

export default EditNewHunt