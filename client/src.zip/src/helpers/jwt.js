export const getJwt = () => {
    return localStorage.getItem('unlockit-jwt')
};