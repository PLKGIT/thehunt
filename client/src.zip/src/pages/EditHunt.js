import React, { Component } from 'react';
import EditNewHunt from "../components/EditNewHunt/index"

class EditHunt extends Component {
    render() {
        return (
            <EditNewHunt />
        )
    }
}

export default EditHunt;